Traveling Typewriter.
Freeware Created by Carl Krul 2006.
This font is based on an old danish "Olympia Traveller de luxe" typewriter, made in Western Germany. The font is free for personal use only.